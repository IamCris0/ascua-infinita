extends RefCounted
## Shared native atlas resources. No runtime pixel processing or source-sheet imports.
const ROOT = "res://assets/gemini/"
var characters: Dictionary = {}
var backgrounds: Array[Texture2D] = []
var relics: Array[Texture2D] = []
var effects: SpriteFrames

func _init() -> void:
	for key in ["hero", "slime", "wisp", "sentinel", "boss"]:
		characters[key] = load(ROOT + "animations/" + key + ".tres")
	for key in ["garden", "crypt", "forge"]:
		backgrounds.append(load(ROOT + "backgrounds/" + key + ".png"))
	for i in range(7):
		relics.append(load(ROOT + "animations/relic_%d.tres" % i))
	effects = load(ROOT + "animations/effects.tres")

func frame_index(frames: SpriteFrames, animation: String, elapsed: float) -> int:
	var total = frames.get_frame_count(animation)
	var index = int(maxf(0, elapsed) * frames.get_animation_speed(animation))
	return index % total if frames.get_animation_loop(animation) else mini(index, total - 1)

func draw_character(canvas: CanvasItem, key: String, animation: String, elapsed: float, feet: Vector2, height: float, modulate: Color = Color.WHITE) -> void:
	var frames: SpriteFrames = characters[key]
	var index = frame_index(frames, animation, elapsed)
	var texture = frames.get_frame_texture(animation, index)
	var pivot: Vector2 = frames.get_meta("pivots")[animation][index]
	var scale = height / float(frames.get_meta("reference_height")) * float(frames.get_meta("scales").get(animation, 1.0))
	var drawn_size = texture.get_size() * scale
	var flipped: bool = frames.get_meta("flip_left")
	if flipped:
		pivot.x = texture.get_width() - pivot.x
	var position = feet - pivot * scale
	if flipped:
		position.x += drawn_size.x
		drawn_size.x = -drawn_size.x
	canvas.draw_texture_rect(texture, Rect2(position, drawn_size), false, modulate)

func draw_effect(canvas: CanvasItem, animation: String, elapsed: float, center: Vector2, width: float, modulate: Color = Color.WHITE) -> void:
	var index = frame_index(effects, animation, elapsed)
	canvas.draw_texture_rect(effects.get_frame_texture(animation, index), Rect2(center - Vector2.ONE * width * 0.5, Vector2.ONE * width), false, modulate)
