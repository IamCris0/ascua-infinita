# Material recibido de Gemini

Once imágenes entregadas por el usuario el 2 de octubre de 2026, generadas en Gemini según su indicación. Copias originales sin retoques; cada copia se comprobó mediante SHA-256 contra el archivo adjunto. Este directorio está excluido de la importación de Godot mediante `.gdignore` porque contiene material fuente, todavía no assets preparados para ejecución.

## Inventario y revisión

| Archivo | Dimensiones | Uso y preparación pendiente |
|---|---|---|
| 01_referencia_interfaz.png | 1024 × 559 | Referencia de dirección visual. Es una composición completa, no componentes de interfaz separados. |
| 02_portador.png | 1024 × 559 | Hoja de personaje con varias filas. Separar poses, retirar fondo, alinear pies y establecer secuencias. |
| 03_gelatina.png | 1024 × 559 | Hoja irregular con celdas vacías y líneas divisorias. Preparar fotogramas y transparencia. |
| 04_lucero.png | 1024 × 559 | Hoja de tres filas ocupadas. Preparar fotogramas, transparencia y secuencias. |
| 05_centinela.png | 1024 × 559 | Poses de distintos anchos. Preparar transparencia, pivotes y orientación del ataque. |
| 06_rey_sin_brasa.png | 1024 × 559 | Poses y efectos de diferentes tamaños. Preparar transparencia, pivotes y orientación del ataque. |
| 07_jardin_cenizas.png | 1024 × 800 | Fondo utilizable. Adaptar encuadre y posiciones de combate al escenario. |
| 08_criptas_eco.png | 1024 × 800 | Fondo utilizable. Adaptar encuadre y posiciones de combate al escenario. |
| 09_forja_eclipse.png | 1024 × 800 | Fondo utilizable. Adaptar encuadre y posiciones de combate al escenario. |
| 10_reliquias.png | 1024 × 144 | Siete iconos con rótulos y bordes. Extraer objetos, eliminar fondo y conservar el texto como UI independiente. |
| 11_efectos.png | 1024 × 1024 | Efectos por filas; primera fila con tres arcos visibles. Extraer y definir tiempos sin asumir cuatro poses completas por fila. |

## Transparencia

Las once imágenes son PNG RGB de 24 bits, sin canal alfa. El tablero gris de los personajes, iconos y efectos forma parte de los píxeles de las imágenes. No basta con guardar de nuevo como PNG: hace falta preparar máscaras de transparencia que conserven los grises del casco, las armaduras y las armas.

## Compatibilidad

Las hojas no siguen la tira original de 16 celdas de 32 × 32 utilizada en `scripts/arena.gd`. Las poses tienen mayor resolución y distribuciones distintas. Conviene preservar ese detalle y preparar un atlas con regiones y pivotes explícitos, en lugar de reducir directamente toda la imagen a 512 × 32.

Estos archivos no han sustituido los assets activos del juego. Su procedencia es distinta de los SVG y WAV generados originalmente en el proyecto.
